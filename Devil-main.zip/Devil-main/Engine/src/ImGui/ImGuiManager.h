#pragma once

struct ID3D11Device;
struct ID3D11DeviceContext;

namespace Devil
{
	class ImGuiManager
	{
	public:
		ImGuiManager();
		~ImGuiManager();
	};
}