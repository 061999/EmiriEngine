#pragma once

#define BIT(x) (1 << x)

#define DegreeToRadian(d) (d * 0.0174532925f)
#define RadianToDegree(r) (r / 0.0174532925f)