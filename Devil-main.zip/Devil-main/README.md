# Devil Engine

受尽苦难而不厌，此乃修罗之道。

## Graphics API

The default renderer is **DirectX 11** on Windows.

## Usage

For Windows, run [ **Win64-BuildProject.bat** ]. ( need VS2022 and CMake )

Then you can run [ **Win64-CompileCMake-Debug.bat** ] or [ **Win64-CompileCMake-Release.bat** ] to compile this project.